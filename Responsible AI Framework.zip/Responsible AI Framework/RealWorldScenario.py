# ai_diagnosis.py

import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from PIL import Image, ImageDraw, ImageFont
import random

# Sample medical dataset (can be replaced with a real one)
data = {
    "symptoms": [
        "fever, cough, fatigue",
        "headache, vision blur, nausea",
        "chest pain, shortness of breath",
        "rash, itching, swelling",
        "abdominal pain, vomiting, diarrhea",
        "sneezing, runny nose, congestion",
        "itchy eyes, watery eyes, sneezing",
        "loss of taste, loss of smell, fever",
        "wheezing, coughing, chest tightness",
        "nasal congestion, facial pain, headache",
        "sore throat, runny nose, fatigue",
        "dry cough, high fever, difficulty breathing",
        "joint pain, stiffness, fatigue",
        "burning urination, frequent urination, lower back pain",
        "painful periods, pelvic pain, fatigue",
        "weight loss, night sweats, swollen lymph nodes",
        "increased thirst, frequent urination, blurred vision",
        "nausea, vomiting, yellow skin, fatigue",
        "cold hands, cold feet, chest pain, fatigue",
        "muscle weakness, double vision, drooping eyelids"
    ],
    "diagnosis": [
        "Flu",
        "Migraine",
        "Heart Disease",
        "Allergy",
        "Food Poisoning",
        "Common Cold",
        "Hay Fever",
        "COVID-19",
        "Asthma",
        "Sinusitis",
        "Viral Infection",
        "COVID-19",
        "Arthritis",
        "Urinary Tract Infection",
        "Endometriosis",
        "Tuberculosis",
        "Diabetes",
        "Hepatitis",
        "Anemia",
        "Myasthenia Gravis"
    ]
}

df = pd.DataFrame(data)

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    df["symptoms"], df["diagnosis"], test_size=0.2, random_state=42)

# Create pipeline
model = Pipeline([
    ('vectorizer', CountVectorizer()),
    ('classifier', MultinomialNB())
])

# Train model
model.fit(X_train, y_train)

# Predict


def diagnose(symptoms_input):
    prediction = model.predict([symptoms_input])[0]
    prob = max(model.predict_proba([symptoms_input])[0])
    return prediction, prob


# Example patient input
patient_symptoms = input(
    "Enter patient symptoms (e.g., 'fever cough fatigue'): ")
diagnosis, confidence = diagnose(patient_symptoms)

print(f"\nPredicted Diagnosis: {diagnosis}")
print(f"Confidence: {confidence:.2f}")

# Save diagnosis report
with open("diagnosis_report.txt", "w") as file:
    file.write(f"Patient Symptoms: {patient_symptoms}\n")
    file.write(f"Predicted Diagnosis: {diagnosis}\n")
    file.write(f"Confidence Score: {confidence:.2f}\n")

# Canva image generation - placeholder function (use Canva manually or API)


def generate_canva_image(symptoms, diagnosis, confidence):
    print(
        f"\n Canva Diagnostic Image Generation\nSymptoms: {symptoms}\nDiagnosis: {diagnosis}\nConfidence: {confidence:.2f}")
    print("→ Use Canva (https://www.canva.com/) to create a visual report with this data.")


generate_canva_image(patient_symptoms, diagnosis, confidence)


def generate_diagnosis_image(symptoms, diagnosis, confidence, filename="diagnosis_image.png"):
    width, height = 800, 400
    image = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(image)

    # Load a font (use default or provide a TTF path)
    try:
        font = ImageFont.truetype("arial.ttf", 24)
    except:
        font = ImageFont.load_default()

    # Prepare text
    lines = [
        "AI Medical Diagnosis Report",
        "",
        f"Symptoms: {symptoms}",
        f"Diagnosis: {diagnosis}",
        f"Confidence: {confidence:.2f}",
    ]

    # Draw text
    y_text = 50
    for line in lines:
        draw.text((50, y_text), line, font=font, fill="black")
        y_text += 40

    # Save image
    image.save(filename)
    print(f"\nImage saved as: {filename}")

    # Optional: display image
    image.show()


# Call the image generator
generate_diagnosis_image(patient_symptoms, diagnosis, confidence)